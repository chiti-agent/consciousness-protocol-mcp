#!/usr/bin/env node
"use strict";

// Minimal MCP server: reads stdio JSON-RPC, responds to initialize, then exits.
const readline = require("readline");

const rl = readline.createInterface({ input: process.stdin });
rl.on("line", (line) => {
  try {
    const msg = JSON.parse(line);
    if (msg.method === "initialize") {
      const response = {
        jsonrpc: "2.0",
        id: msg.id,
        result: {
          protocolVersion: "2025-01-01",
          serverInfo: { name: "test-mcp-server", version: "0.1.0" },
          capabilities: {},
        },
      };
      process.stdout.write(JSON.stringify(response) + "\n");
    }
  } catch {}
});

// Exit after 1 second if no input
setTimeout(() => process.exit(0), 1000);
